def __main__():
	print("COOL")

if __name__ == "__main__":
	print("cooool")
